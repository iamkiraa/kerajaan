<?php
include('check_cust.php');
include('header_cust.php');
include('connection.php');
$custID = $_SESSION["ID"];
?>
<!-- Content start here -->
<div class="panel panel-default container" style="margin-top:10px">

<br/>
<div class="panel-body"> 
<h4>Frequently Ask Question (FAQ)</h4>

<!-- First Grid -->
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
      <br/>
      
	  <h5 class="w3-padding-32">Sukan</h5>
		<ul>
			<li> Apakah kemudahan pengangkutan yang terdapat di Terengganu? </li>
		<ul>	
		<p class="w3-text-grey">
			- Beca, bas, teksi, bot penambang
	    </p>
		
		<h5 class="w3-padding-32">Kemudahan</h5>
		<ul>
			<li> Bagaimana untuk menghubungi pihak Pejabat Setiausaha Kerajaan Negeri Terengganu? </li>
		<ul>	
		<p class="w3-text-grey">
			- Sebarang kesulitan menghubungi nombor telefon Pejabat Setiausaha Kerajaan Negeri Terengganu iaitu 09-6231957 diikuti nombor sambungan pegawai berkenaan. Beca, bas, teksi, bot penambang.
	    </p>
		
		<h5 class="w3-padding-32">Pelaburan</h5>
		<ul>
			<li> Bagaimanakah saya ingin mengetahui tentang peluang pelaburan di Terengganu? </li>
		<ul>	
		<p class="w3-text-grey">
			- Anda boleh ke laman Hotspot di menu Pelaburan di laman Portal.
	    </p>
    </div>
<br/>

</div> <!-- /.content -->
</div> <!-- /.container -->

</body></html>